const Teacher = require('../models/Teacher');
const jwt = require('jsonwebtoken');

const jwtSecret = process.env.JWT_SECRET;

// 🔹 REGISTER TEACHER
exports.registerTeacher = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const existingTeacher = await Teacher.findOne({ email });
    if (existingTeacher) {
      return res.status(400).json({ message: 'Teacher already exists' });
    }

    // ❗ Direct password pass karo (model khud hash karega)
    const teacher = new Teacher({
      name,
      email,
      password
    });

    await teacher.save();

    res.status(201).json({ message: 'Teacher registered successfully' });

  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ message: 'Registration failed', error });
  }
};


// 🔹 LOGIN TEACHER
exports.loginTeacher = async (req, res) => {
  const { email, password } = req.body;

  try {
    const teacher = await Teacher.findOne({ email });
    if (!teacher) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // ❗ Model ka comparePassword method use karo
    const isMatch = await teacher.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { id: teacher._id },
      jwtSecret,
      { expiresIn: '1h' }
    );

    res.status(200).json({ token });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Login failed', error });
  }
};
