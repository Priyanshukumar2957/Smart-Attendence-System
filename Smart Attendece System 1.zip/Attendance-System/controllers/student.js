const Student = require('../models/Student');

// Get students by class
exports.getStudentsByClass = async (req, res) => {
  const { className } = req.params;

  try {
    // Find students in the specified class
    const students = await Student.find({ class: className });

    if (students.length === 0) {
      return res.status(404).json({ message: 'No students found in this class' });
    }

    res.json(students);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch students', error });
  }
};
