import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { ChakraProvider } from "@chakra-ui/react";

import Dashboard from "./Dashboard";
import AttendancePage from "./Attendance";
import Summery from "./Summery";
import Register from "./Register";
import Login from "./Login";

function App() {

  const router = createBrowserRouter([
    {
      path: "/",
      element: <Login />   // ✅ Default page changed
    },
    {
      path: "/register",
      element: <Register />
    },
    {
      path: "/attend",
      element: (
        <>
          <Dashboard />
          <AttendancePage />
        </>
      )
    },
    {
      path: "/summery",
      element: (
        <>
          <Dashboard />
          <Summery />
        </>
      )
    },
    {
      path: "*",
      element: <h1>Page Not Found</h1>
    }
  ]);

  return (
    <ChakraProvider>
      <RouterProvider router={router} />
    </ChakraProvider>
  );
}

export default App;
